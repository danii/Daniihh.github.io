
/*
  Types
*/
type Getter = () => any;
type Setter = (v: any) => void;
type Pair<K, V> = [K, V];
type Entry<T> = Pair<Key, T>;
type Of<T> = {[key: string]: T};
type Key = string | number | symbol;
type Constructor<T> = new(...args: any[]) => T;
type Prototype<T> = {constructor: Constructor<T>};
type StackFrame = {
  file: string,
  methodName: string,
  arguments: string[],
  lineNumber: number,
  column: number
};



/*
  Definitions
*/
let defineProperties = <T>(target: T, values: Partial<T>) => {
  let reducer = (map, key) => ({...map, [key]: {...Object.getOwnPropertyDescriptor(values, key), "enumerable": false}});
  Object.defineProperties(target, Object.keys(values).reduce<PropertyDescriptorMap>(reducer, {}));
}

interface Array<T> {
  last: T;

  crumbleFlat(): null | T | T[];
  crumble(): null | T | T[];
  softReverse(): T[];

  reduce<U = T>(callbackfn: (previousValue: U | T, currentValue: T, currentIndex: number, array: T[]) => U): U | T;
}

defineProperties(Array.prototype, {
  get last(this: any[]) {
    return this[Math.max(0, this.length - 1)];
  },

  set last(item: any) {
    this[Math.max(0, this.length - 1)] = item;
  },

  crumble() {
    let switchObj = {
      "0": null,
      "1": this[0],
      "default": this,
    };
  
    return switchObj[this.length] !== undefined ?
        switchObj[this.length] :
        switchObj.default;
  },
  
  crumbleFlat() {
    return this.flat().crumble();
  },

  softReverse() {
    let ret = [];
    for (let entry of Array.from(this.entries())) ret[entry[0] * -1 + this.length - 1] = entry[1];
    return ret;
  }
} as Partial<any[]>);

interface ObjectConstructor {
  clone<T extends Object>(item: T): T;
  getType(item: any): string;

  getPrototypeOf<T>(o: T): Prototype<T>;
  getPrototypeOf(o: any): any;
}

defineProperties(Object, {
  clone<T extends Object>(item: T): T {
    let Construct: any = item.constructor;
    return Object.assign(new Construct(), item);
  },

  getType(item: any) {
    return Object.getPrototypeOf(item).constructor.name;
  }
});

interface String {
  capitalize(): string;
  escape(): string;
  toTitleCase(): string;
}

Array.prototype.splice(1, 2, )

defineProperties(String.prototype, {
  capitalize() {
    return this.substr(0, 1).toUpperCase() + this.substr(1);
  },

  escape() {
    let charArray = this.split("");
    charArray = charArray.map((char) => ['"', "'", "\\"].includes(char) ? "\\" + char : char);
    return charArray.join("");
  },

  toTitleCase() {
    return this.split(" ").map((word) => word.toLowerCase().capitalize()).join(" ");
  }
} as Partial<String>);



/*
  Errors
*/
class AdvancedError extends Error {
  private static readonly UNKNOWN_FUNCTION = '<unknown>';

  /**
   * Creates a class that extends this class.
   * 
   * @param name The name of the new class.
   * @returns A class constructor function extending this class.
   */
  public static extend(name: string): typeof AdvancedError {
    name = name.capitalize();
    let {[name]: extended} = {[name]: class extends this {}};
    return extended;
  }

  public static stringifyStack(error: Error) {
    if (!(error instanceof AdvancedError)) return error.stack;

    let errors: Error[] = [error];
    while (error instanceof AdvancedError && error.suppressed)
        errors.push(error = error.suppressed);

    let string = "";
    let lastStack: StackFrame[];
    errors.forEach((error, index) => {
      let fullStack = error instanceof AdvancedError ?
          error.stackMap :
          (errors[index - 1] as AdvancedError).suppressedStackMap;

      let usedStack = Object.clone(fullStack);
      if (lastStack) {
        let rLastStack = lastStack.softReverse();
        let lcsf = usedStack.softReverse().find((frame, index) => {
          let compare = rLastStack[index];
          return !compare || frame.methodName != compare.methodName ||
              frame.file != compare.file;
        });
        usedStack.splice(usedStack.indexOf(lcsf) + 2);
      }
      
      string += (index != 0 ? "\nCaused by: " : "") + error.name;
      if (error.message) string += ": " + error.message;
      usedStack.forEach((stack) => {
        string += "\n\tas " + stack.methodName + " (" + stack.file + ":" +
            stack.lineNumber + ":" + stack.column + ")";
      });
      if (usedStack.length < fullStack.length)
          string += "\n\t... " + (fullStack.length - usedStack.length) + " more";

      lastStack = fullStack;
    });
    return string;
  }

  public static parseStack(stackString: string): StackFrame[] {
    const lines = stackString.split('\n');

    return lines.reduce((stack, line) => {
      const parseResult =
        AdvancedError.parseChrome(line) ||
        AdvancedError.parseWinjs(line) ||
        AdvancedError.parseGecko(line) ||
        AdvancedError.parseNode(line) ||
        AdvancedError.parseJSC(line);

      if (parseResult) {
        stack.push(parseResult);
      }

      return stack;
    }, []);
  }
  
  private static parseChrome(line: string): StackFrame {
    const chromeRe = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
    const chromeEvalRe = /\((\S*)(?::(\d+))(?::(\d+))\)/;

    const parts = chromeRe.exec(line);

    if (!parts) {
      return null;
    }

    const isNative = parts[2] && parts[2].indexOf('native') === 0; // start of line
    const isEval = parts[2] && parts[2].indexOf('eval') === 0; // start of line

    const submatch = chromeEvalRe.exec(parts[2]);
    if (isEval && submatch != null) {
      // throw out eval line/column and use top-most line/column number
      parts[2] = submatch[1]; // url
      parts[3] = submatch[2]; // line
      parts[4] = submatch[3]; // column
    }

    return {
      file: !isNative ? parts[2] : null,
      methodName: parts[1] || AdvancedError.UNKNOWN_FUNCTION,
      arguments: isNative ? [parts[2]] : [],
      lineNumber: parts[3] ? +parts[3] : null,
      column: parts[4] ? +parts[4] : null,
    };
  }

  
  private static parseWinjs(line: string): StackFrame {
    const winjsRe = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;

    const parts = winjsRe.exec(line);

    if (!parts) {
      return null;
    }

    return {
      file: parts[2],
      methodName: parts[1] || AdvancedError.UNKNOWN_FUNCTION,
      arguments: [],
      lineNumber: +parts[3],
      column: parts[4] ? +parts[4] : null,
    };
  }
  
  private static parseGecko(line: string): StackFrame {
    const geckoRe = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i;
    const geckoEvalRe = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
  
    const parts = geckoRe.exec(line);

    if (!parts) {
      return null;
    }

    const isEval = parts[3] && parts[3].indexOf(' > eval') > -1;

    const submatch = geckoEvalRe.exec(parts[3]);
    if (isEval && submatch != null) {
      // throw out eval line/column and use top-most line number
      parts[3] = submatch[1];
      parts[4] = submatch[2];
      parts[5] = null; // no column when eval
    }

    return {
      file: parts[3],
      methodName: parts[1] || AdvancedError.UNKNOWN_FUNCTION,
      arguments: parts[2] ? parts[2].split(',') : [],
      lineNumber: parts[4] ? +parts[4] : null,
      column: parts[5] ? +parts[5] : null,
    };
  }

  private static parseJSC(line: string): StackFrame {
    const javaScriptCoreRe = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i;
    
    const parts = javaScriptCoreRe.exec(line);

    if (!parts) {
      return null;
    }

    return {
      file: parts[3],
      methodName: parts[1] || AdvancedError.UNKNOWN_FUNCTION,
      arguments: [],
      lineNumber: +parts[4],
      column: parts[5] ? +parts[5] : null,
    };
  }

  private static parseNode(line: string): StackFrame {
    const nodeRe = /^\s*at (?:((?:\[object object\])?\S+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i;
    
    const parts = nodeRe.exec(line);

    if (!parts) {
      return null;
    }

    return {
      file: parts[2],
      methodName: parts[1] || AdvancedError.UNKNOWN_FUNCTION,
      arguments: [],
      lineNumber: +parts[3],
      column: parts[4] ? +parts[4] : null,
    };
  }

  public readonly stack: any;
  public readonly message: any;
  private displayedStack: string;
  private readonly description: string;
  private readonly stackMap: StackFrame[];

  public readonly suppressed?: Error;
  private suppressedStackMap?: StackFrame[];

  public constructor(message?: string | Error, suppressed?: Error) {
    if (message instanceof Error) [message, suppressed] = [undefined as string, message];
    super();

    // if (!(this instanceof arguments.callee)) {
    //   let Construct = arguments.callee as Constructor<any>;
    //   let thiz = Object.create(Construct.prototype);
    //   eval("_this = thiz");

    //   let protos: Constructor<any>[] = [];
    //   let Proto = Construct;
    //   while (Proto.name != "") {
    //     Proto = Object.getPrototypeOf(Proto);
    //     protos.unshift(Proto);
    //   }
    //   let reducer = (thiz: AdvancedError, proto) => {return proto.call(thiz), thiz;};
    //   thiz = protos.reduce(reducer, this);
    //   eval("_this = thiz");

    //   let p = new Error();
    //   this.stack = p.stack;
    // }

    this.description = message;
    this.name = this.constructor.name;
    this.stackMap = AdvancedError.parseStack(this.stack);
    
    if (suppressed) {
      this.suppressed = suppressed;
      if (!(suppressed instanceof AdvancedError)) {
        this.suppressedStackMap = AdvancedError.parseStack(suppressed.stack);
      }
    }

    let hidden = <C>(common: C) => {
      return {
        get(this: AdvancedError): string | C {
          if (AdvancedError.parseStack(new Error().stack).length > 1) {
            return common;
          } else {
            console.debug("Error thrown: ", this);
            return this.displayedStack;
          }
        }
      }
    };
    Object.defineProperties(this, {
      "stack": hidden(this.stackMap),
      "message": hidden(this.description)
    });

    this.displayedStack = AdvancedError.stringifyStack(this);
  }

  public toString() {
    return this.displayedStack;
  }
}

let ArgumentsError = AdvancedError.extend("ArgumentsError");
